<?php
    $conn=mysqli_connect('db4free.net','saurass123','Special@04','scrapper');
?>